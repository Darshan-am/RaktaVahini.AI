package com.raktavahiniai.data.local.entities

class DonationEntity {
}