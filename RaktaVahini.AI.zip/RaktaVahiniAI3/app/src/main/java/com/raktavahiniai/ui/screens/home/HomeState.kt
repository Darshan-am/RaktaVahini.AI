package com.raktavahiniai.ui.screens.home

class HomeState {
}