package com.raktavahiniai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(

    primary = BloodRed,

    background = Color(0xFF121212),

    surface = Color(0xFF1E1E1E),

    onPrimary = Color.White,

    onBackground = Color.White,

    onSurface = Color.White
)

private val LightColors = lightColorScheme(

    primary = BloodRed,

    background = Color.White,

    surface = Color.White,

    onPrimary = Color.White,

    onBackground = Color.Black,

    onSurface = Color.Black
)

@Composable
fun RaktaVahiniAITheme(
    darkTheme: Boolean,
    content: @Composable () -> Unit
) {

    val colors =
        if (darkTheme)
            DarkColors
        else
            LightColors

    MaterialTheme(

        colorScheme = colors,

        typography = Typography,

        content = content
    )
}