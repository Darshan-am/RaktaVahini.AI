package com.raktavahiniai.dto

data class AiRequest(
    val question: String
)