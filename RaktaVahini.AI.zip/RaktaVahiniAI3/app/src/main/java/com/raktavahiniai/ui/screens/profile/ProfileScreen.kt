package com.raktavahiniai.ui.screens.profile

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.google.firebase.auth.FirebaseAuth
import com.raktavahiniai.navigation.NavRoutes
import com.raktavahiniai.ui.theme.ThemeViewModel
import com.raktavahiniai.utils.LanguageManager

@Composable
fun ProfileScreen(
    navController: NavController,
    themeViewModel: ThemeViewModel
) {

    val selectedLanguage =
        LanguageManager.selectedLanguage

    val user =
        FirebaseAuth
            .getInstance()
            .currentUser

    var imageUri by remember {
        mutableStateOf<Uri?>(null)
    }

    val launcher =
        rememberLauncherForActivityResult(
            contract =
                ActivityResultContracts.GetContent()
        ) { uri ->

            imageUri = uri
        }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {

        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment =
                Alignment.Center
        ) {

            Column(
                horizontalAlignment =
                    Alignment.CenterHorizontally
            ) {

                AsyncImage(
                    model = imageUri,
                    contentDescription = null,
                    modifier = Modifier.size(120.dp)
                )

                Spacer(
                    modifier = Modifier.height(12.dp)
                )

                Button(
                    onClick = {

                        launcher.launch("image/*")
                    }
                ) {

                    Text(

                        when (
                            selectedLanguage.value
                        ) {

                            "Kannada" ->
                                "ಫೋಟೋ ಆಯ್ಕೆಮಾಡಿ"

                            "Hindi" ->
                                "फोटो चुनें"

                            else ->
                                "Choose Photo"
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text =

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "ಪ್ರೊಫೈಲ್"

                    "Hindi" ->
                        "प्रोफ़ाइल"

                    else ->
                        "Profile"
                },

            style =
                MaterialTheme
                    .typography
                    .headlineMedium
        )

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text =
                "Email: ${user?.email ?: "Unknown"}"
        )

        Spacer(modifier = Modifier.height(32.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement =
                Arrangement.SpaceBetween,
            verticalAlignment =
                Alignment.CenterVertically
        ) {

            Text(

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "ಡಾರ್ಕ್ ಮೋಡ್"

                    "Hindi" ->
                        "डार्क मोड"

                    else ->
                        "Dark Mode"
                }
            )

            Switch(
                checked =
                    themeViewModel
                        .isDarkMode
                        .value,

                onCheckedChange = {

                    themeViewModel
                        .toggleTheme()
                }
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = {

                FirebaseAuth
                    .getInstance()
                    .signOut()

                navController.navigate(
                    NavRoutes.LOGIN
                ) {

                    popUpTo(0)
                }
            },

            modifier =
                Modifier.fillMaxWidth()
        ) {

            Text(

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "ಲಾಗ್ ಔಟ್"

                    "Hindi" ->
                        "लॉग आउट"

                    else ->
                        "Logout"
                }
            )
        }
    }
}