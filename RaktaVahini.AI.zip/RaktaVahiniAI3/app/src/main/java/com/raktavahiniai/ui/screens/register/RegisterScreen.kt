package com.raktavahiniai.ui.screens.register

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.raktavahiniai.model.Donor
import com.raktavahiniai.navigation.NavRoutes
import com.raktavahiniai.repository.DonorRepository

@OptIn(
    ExperimentalMaterial3Api::class
)

@Composable
fun RegisterScreen(

    navController: NavController

) {

    val context =
        LocalContext.current

    val auth =
        FirebaseAuth.getInstance()

    val selectedLanguage =
        remember {

            mutableStateOf(
                "English"
            )
        }

    var fullName by remember {

        mutableStateOf("")
    }

    var email by remember {

        mutableStateOf("")
    }

    var phone by remember {

        mutableStateOf("")
    }

    var district by remember {

        mutableStateOf("")
    }

    var password by remember {

        mutableStateOf("")
    }

    val bloodGroups = listOf(

        "A+",
        "A-",
        "B+",
        "B-",
        "AB+",
        "AB-",
        "O+",
        "O-"
    )

    var expanded by remember {

        mutableStateOf(
            false
        )
    }

    var selectedBloodGroup by remember {

        mutableStateOf("")
    }

    Column(

        modifier = Modifier

            .fillMaxSize()

            .padding(20.dp)

            .verticalScroll(
                rememberScrollState()
            )

    ) {

        Text(

            "🩸 Rakta-Vahini",

            style =
                MaterialTheme
                    .typography
                    .headlineMedium
        )

        Spacer(
            Modifier.height(
                20.dp
            )
        )

        OutlinedTextField(

            value = fullName,

            onValueChange = {

                fullName = it
            },

            modifier =
                Modifier.fillMaxWidth(),

            label = {

                Text("Full Name")
            }
        )

        Spacer(
            Modifier.height(
                10.dp
            )
        )

        OutlinedTextField(

            value = email,

            onValueChange = {

                email = it
            },

            modifier =
                Modifier.fillMaxWidth(),

            label = {

                Text("Email")
            }
        )

        Spacer(
            Modifier.height(
                10.dp
            )
        )

        OutlinedTextField(

            value = phone,

            onValueChange = {

                phone = it
            },

            modifier =
                Modifier.fillMaxWidth(),

            label = {

                Text("Phone")
            }
        )

        Spacer(
            Modifier.height(
                10.dp
            )
        )

        OutlinedTextField(

            value = district,

            onValueChange = {

                district = it
            },

            modifier =
                Modifier.fillMaxWidth(),

            label = {

                Text("District")
            }
        )

        Spacer(
            Modifier.height(
                10.dp
            )
        )

        ExposedDropdownMenuBox(

            expanded = expanded,

            onExpandedChange = {

                expanded =
                    !expanded
            }

        ) {

            OutlinedTextField(

                value =
                    selectedBloodGroup,

                onValueChange = { },

                readOnly = true,

                modifier =
                    Modifier.fillMaxWidth(),

                label = {

                    Text(
                        "Blood Group"
                    )
                }
            )

            ExposedDropdownMenu(

                expanded =
                    expanded,

                onDismissRequest = {

                    expanded =
                        false
                }

            ) {

                bloodGroups.forEach {

                    DropdownMenuItem(

                        text = {

                            Text(it)
                        },

                        onClick = {

                            selectedBloodGroup =
                                it

                            expanded =
                                false
                        }
                    )
                }
            }
        }

        Spacer(
            Modifier.height(
                10.dp
            )
        )

        OutlinedTextField(

            value = password,

            onValueChange = {

                password = it
            },

            modifier =
                Modifier.fillMaxWidth(),

            visualTransformation =

                PasswordVisualTransformation(),

            label = {

                Text("Password")
            }
        )

        Spacer(
            Modifier.height(
                20.dp
            )
        )

        Button(

            onClick = {

                auth

                    .createUserWithEmailAndPassword(

                        email,

                        password

                    )

                    .addOnCompleteListener {

                        if (

                            it.isSuccessful

                        ) {

                            val donor =

                                Donor(

                                    name =
                                        fullName,

                                    email =
                                        email,

                                    phone =
                                        phone,

                                    bloodGroup =
                                        selectedBloodGroup,

                                    city =
                                        district
                                )

                            DonorRepository
                                .saveDonor(
                                    donor
                                )

                            Toast.makeText(

                                context,

                                "Donor Registered",

                                Toast.LENGTH_SHORT

                            ).show()

                            navController.navigate(

                                NavRoutes.SEARCH_DONOR
                            )

                        } else {

                            Toast.makeText(

                                context,

                                "Registration Failed",

                                Toast.LENGTH_SHORT

                            ).show()
                        }
                    }
            },

            modifier =
                Modifier.fillMaxWidth()

        ) {

            Text(
                "Register"
            )
        }
    }
}