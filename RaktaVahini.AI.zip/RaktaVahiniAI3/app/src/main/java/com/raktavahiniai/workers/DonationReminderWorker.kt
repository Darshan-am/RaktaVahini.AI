package com.raktavahiniai.workers

class DonationReminderWorker {
}