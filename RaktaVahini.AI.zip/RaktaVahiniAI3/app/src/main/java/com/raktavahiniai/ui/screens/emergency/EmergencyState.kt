package com.raktavahiniai.ui.screens.emergency

class EmergencyState {
}