package com.raktavahiniai.ui.screens.donor

class DonorState {
}