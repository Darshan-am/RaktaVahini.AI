package com.raktavahiniai.ui.components

class LoadingView {
}