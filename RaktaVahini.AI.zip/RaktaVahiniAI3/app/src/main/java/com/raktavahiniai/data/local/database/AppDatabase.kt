package com.raktavahiniai.data.local.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.raktavahiniai.data.local.dao.EmergencyDao
import com.raktavahiniai.data.local.dao.UserDao
import com.raktavahiniai.data.local.entities.EmergencyEntity
import com.raktavahiniai.data.local.entities.UserEntity

@Database(
    entities = [
        UserEntity::class,
        EmergencyEntity::class
    ],
    version = 1,
    exportSchema = false
)

abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao

    abstract fun emergencyDao(): EmergencyDao
}