package com.raktavahiniai.ui.screens.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.raktavahiniai.R

object NotificationScreen {

    private const val CHANNEL_ID =
        "raktavahini_channel"

    fun createNotificationChannel(

        context: Context

    ) {

        if (

            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.O

        ) {

            val channel =

                NotificationChannel(

                    CHANNEL_ID,

                    "Rakta-Vahini AI",

                    NotificationManager
                        .IMPORTANCE_HIGH
                )

            val manager =

                context.getSystemService(

                    NotificationManager::class.java

                )

            manager.createNotificationChannel(
                channel
            )
        }
    }

    fun showLoginNotification(

        context: Context,

        language: String

    ) {

        val title =

            when (
                language
            ) {

                "Kannada" ->
                    "🩸 ಲಾಗಿನ್ ಯಶಸ್ವಿಯಾಗಿದೆ"

                "Hindi" ->
                    "🩸 लॉगिन सफल"

                else ->
                    "🩸 Login Successful"
            }

        val message =

            when (
                language
            ) {

                "Kannada" ->
                    "ರಕ್ತವಾಹಿನಿ AI ಗೆ ಸ್ವಾಗತ"

                "Hindi" ->
                    "रक्तवाहिनी AI ಗೆ स्वागत"

                else ->
                    "Welcome to Rakta-Vahini AI"
            }

        val notification =

            NotificationCompat.Builder(

                context,

                CHANNEL_ID

            )

                .setSmallIcon(
                    R.mipmap.ic_launcher
                )

                .setContentTitle(
                    title
                )

                .setContentText(
                    message
                )

                .setPriority(
                    NotificationCompat
                        .PRIORITY_HIGH
                )

                .setAutoCancel(
                    true
                )

                .build()

        NotificationManagerCompat

            .from(context)

            .notify(

                1001,

                notification
            )
    }
}