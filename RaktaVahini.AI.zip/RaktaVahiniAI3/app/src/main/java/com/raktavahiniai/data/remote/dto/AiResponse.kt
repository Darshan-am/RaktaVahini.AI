package com.raktavahiniai.dto

data class AiResponse(
    val answer: String
)