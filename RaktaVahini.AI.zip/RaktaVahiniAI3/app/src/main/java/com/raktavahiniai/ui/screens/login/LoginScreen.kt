package com.raktavahiniai.ui.screens.login

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.raktavahiniai.navigation.NavRoutes
import com.raktavahiniai.ui.screens.notification.NotificationScreen


@Composable
fun LoginScreen(

    navController: NavController

) {

    val context =
        LocalContext.current

    val auth =
        FirebaseAuth.getInstance()

    val selectedLanguage = remember {

        mutableStateOf(
            "English"
        )
    }

    var email by remember {

        mutableStateOf("")
    }

    var password by remember {

        mutableStateOf("")
    }

    var showSuccessDialog by remember {

        mutableStateOf(false)
    }

    Column(

        modifier = Modifier

            .fillMaxSize()

            .padding(24.dp)

            .verticalScroll(
                rememberScrollState()
            )

    ) {

        Spacer(
            Modifier.height(
                40.dp
            )
        )

        Text(

            "🩸 Rakta-Vahini",

            style =
                MaterialTheme
                    .typography
                    .headlineLarge
        )

        Spacer(
            Modifier.height(
                20.dp
            )
        )

        OutlinedTextField(

            value = email,

            onValueChange = {

                email = it
            },

            modifier =
                Modifier.fillMaxWidth(),

            label = {

                Text(

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ಇಮೇಲ್"

                        "Hindi" ->
                            "ईमेल"

                        else ->
                            "Email"
                    }
                )
            }
        )

        Spacer(
            Modifier.height(
                16.dp
            )
        )

        OutlinedTextField(

            value = password,

            onValueChange = {

                password = it
            },

            modifier =
                Modifier.fillMaxWidth(),

            label = {

                Text(

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ಪಾಸ್‌ವರ್ಡ್"

                        "Hindi" ->
                            "पासवर्ड"

                        else ->
                            "Password"
                    }
                )
            },

            visualTransformation =
                PasswordVisualTransformation()
        )

        Spacer(
            Modifier.height(
                20.dp
            )
        )

        Button(

            onClick = {

                auth.signInWithEmailAndPassword(

                    email,

                    password

                )

                    .addOnCompleteListener {

                        if (

                            it.isSuccessful

                        ) {

                            NotificationScreen
                                .createNotificationChannel(
                                    context
                                )

                            NotificationScreen
                                .showLoginNotification(

                                    context,

                                    selectedLanguage.value
                                )

                            showSuccessDialog =
                                true

                        } else {

                            Toast.makeText(

                                context,

                                "Login Failed",

                                Toast.LENGTH_LONG

                            ).show()
                        }
                    }
            },

            modifier =
                Modifier.fillMaxWidth()

        ) {

            Text(

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "ಲಾಗಿನ್"

                    "Hindi" ->
                        "लॉगिन"

                    else ->
                        "Login"
                }
            )
        }

        Spacer(
            Modifier.height(
                12.dp
            )
        )

        TextButton(

            onClick = {

                if (

                    email.isNotEmpty()

                ) {

                    auth.sendPasswordResetEmail(
                        email
                    )

                    Toast.makeText(

                        context,

                        "Reset email sent",

                        Toast.LENGTH_LONG

                    ).show()

                }
            }

        ) {

            Text(

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "ಪಾಸ್‌ವರ್ಡ್ ಮರೆತಿರಾ?"

                    "Hindi" ->
                        "पासवर्ड भूल गए?"

                    else ->
                        "Forgot Password?"
                }
            )
        }

        TextButton(

            onClick = {

                navController.navigate(
                    NavRoutes.REGISTER
                )
            }

        ) {

            Text(

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "ಹೊಸ ಬಳಕೆದಾರ ನೋಂದಣಿ"

                    "Hindi" ->
                        "नया उपयोगकर्ता पंजीकरण"

                    else ->
                        "Register New User"
                }
            )
        }
    }

    if (

        showSuccessDialog

    ) {

        AlertDialog(

            onDismissRequest = {

                showSuccessDialog =
                    false
            },

            confirmButton = {

                Button(

                    onClick = {

                        navController.navigate(
                            NavRoutes.HOME
                        )
                    }

                ) {

                    Text("OK")
                }
            },

            title = {

                Text(
                    "🎉 Login Success"
                )
            },

            text = {

                Text(
                    "Welcome To RaktaVahini.AI"
                )
            }
        )
    }
}