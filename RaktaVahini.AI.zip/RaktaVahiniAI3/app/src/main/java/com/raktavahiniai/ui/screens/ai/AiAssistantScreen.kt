package com.raktavahiniai.ui.screens.ai

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.raktavahiniai.network.GeminiApi

@Composable
fun AiAssistantScreen() {

    var userQuestion by remember {

        mutableStateOf("")
    }

    var aiResponse by remember {

        mutableStateOf("")
    }

    val selectedLanguage = remember {

        mutableStateOf("English")
    }

    val languages = listOf(

        "English",
        "Kannada",
        "Hindi"
    )

    var expanded by remember {

        mutableStateOf(false)
    }

    Column(

        modifier = Modifier

            .fillMaxSize()

            .padding(16.dp)

            .verticalScroll(
                rememberScrollState()
            )

    ) {

        Text(

            text = "AI Healthcare Assistant",

            style =
                MaterialTheme
                    .typography
                    .headlineMedium
        )

        Spacer(
            modifier =
                Modifier.height(20.dp)
        )

        Box {

            Button(

                onClick = {

                    expanded = true
                }

            ) {

                Text(
                    selectedLanguage.value
                )
            }

            DropdownMenu(

                expanded = expanded,

                onDismissRequest = {

                    expanded = false
                }

            ) {

                languages.forEach { lang ->

                    DropdownMenuItem(

                        text = {

                            Text(lang)
                        },

                        onClick = {

                            selectedLanguage.value = lang

                            expanded = false
                        }
                    )
                }
            }
        }

        Spacer(
            modifier =
                Modifier.height(20.dp)
        )

        OutlinedTextField(

            value = userQuestion,

            onValueChange = {

                userQuestion = it
            },

            modifier =
                Modifier.fillMaxWidth(),

            label = {

                Text(

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ನಿಮ್ಮ ಪ್ರಶ್ನೆ"

                        "Hindi" ->
                            "अपना प्रश्न"

                        else ->
                            "Ask your question"
                    }
                )
            }
        )

        Spacer(
            modifier =
                Modifier.height(20.dp)
        )

        Button(

            onClick = {

                if (
                    userQuestion.isNotEmpty()
                ) {

                    aiResponse = "Loading..."

                    val finalPrompt =

                        when (
                            selectedLanguage.value
                        ) {

                            "Kannada" ->

                                "Answer in Kannada: $userQuestion"

                            "Hindi" ->

                                "Answer in Hindi: $userQuestion"

                            else ->

                                "Answer in English: $userQuestion"
                        }

                    GeminiApi.askGemini(

                        finalPrompt

                    ) { response: String ->

                        aiResponse = response
                    }
                }
            },

            modifier =
                Modifier.fillMaxWidth()

        ) {

            Text(

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "ಎಐ ಕೇಳಿ"

                    "Hindi" ->
                        "एआई से पूछें"

                    else ->
                        "Ask AI"
                }
            )
        }

        Spacer(
            modifier =
                Modifier.height(24.dp)
        )

        Card(

            modifier =
                Modifier.fillMaxWidth()

        ) {

            Column(

                modifier =
                    Modifier.padding(16.dp)

            ) {

                Text(

                    text = "AI Response",

                    style =
                        MaterialTheme
                            .typography
                            .titleMedium
                )

                Spacer(
                    modifier =
                        Modifier.height(12.dp)
                )

                Text(

                    text = aiResponse,

                    style =
                        MaterialTheme
                            .typography
                            .bodyLarge
                )
            }
        }
    }
}