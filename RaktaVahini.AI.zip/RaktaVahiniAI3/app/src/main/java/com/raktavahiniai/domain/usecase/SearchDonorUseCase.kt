package com.raktavahiniai.domain.usecase

class SearchDonorUseCase {
}