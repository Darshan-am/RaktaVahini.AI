package com.raktavahiniai.utils

class Constants {
}