package com.raktavahiniai.data.local.dao

class DonationDao {
}