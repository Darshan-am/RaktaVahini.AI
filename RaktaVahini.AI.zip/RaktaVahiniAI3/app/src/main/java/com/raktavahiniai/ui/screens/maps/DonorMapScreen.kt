package com.raktavahiniai.ui.screens.maps

import android.content.Context
import android.view.ViewGroup
import androidx.compose.runtime.Composable
import androidx.compose.ui.viewinterop.AndroidView
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker

@Composable
fun DonorMapScreen() {

    AndroidView(

        factory = { context ->

            Configuration
                .getInstance()
                .load(
                    context,
                    context.getSharedPreferences(
                        "osm_pref",
                        Context.MODE_PRIVATE
                    )
                )

            val mapView = MapView(context)

            mapView.setTileSource(
                TileSourceFactory.MAPNIK
            )

            mapView.setMultiTouchControls(true)

            val startPoint = GeoPoint(
                13.3409,
                77.1010
            )

            mapView.controller.setZoom(12.0)

            mapView.controller.setCenter(
                startPoint
            )

            val marker = Marker(mapView)

            marker.position = startPoint

            marker.title = "Blood Donor"

            marker.snippet =
                "Available Donor"

            mapView.overlays.add(marker)

            mapView.layoutParams =
                ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )

            mapView
        }
    )
}