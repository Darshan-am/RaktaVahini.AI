package com.raktavahiniai.ui.screens.history

class HistoryViewModel {
}