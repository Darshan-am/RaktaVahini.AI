package com.raktavahiniai.data.remote.api

class EmergencyApi {
}