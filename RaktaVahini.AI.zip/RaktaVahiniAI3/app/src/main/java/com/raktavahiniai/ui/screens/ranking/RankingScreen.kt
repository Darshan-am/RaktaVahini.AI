package com.raktavahiniai.ui.screens.ranking

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raktavahiniai.utils.LanguageManager

data class TopDonor(

    val name: String,

    val bloodGroup: String,

    val donations: Int
)

@Composable
fun RankingScreen() {

    val selectedLanguage =
        LanguageManager.selectedLanguage

    val donors = listOf(

        TopDonor(
            "Rahul",
            "O+",
            12
        ),

        TopDonor(
            "Anjali",
            "A+",
            9
        ),

        TopDonor(
            "Kiran",
            "B+",
            7
        ),

        TopDonor(
            "Sneha",
            "AB+",
            5
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {

        Text(
            text =

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "🏆 ಅತ್ಯುತ್ತಮ ದಾನಿಗಳು"

                    "Hindi" ->
                        "🏆 शीर्ष दाता"

                    else ->
                        "🏆 Top Donors"
                },

            style =
                MaterialTheme
                    .typography
                    .headlineMedium
        )

        Spacer(modifier = Modifier.height(20.dp))

        LazyColumn {

            items(donors) { donor ->

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                ) {

                    Column(
                        modifier = Modifier
                            .padding(20.dp)
                    ) {

                        Text(
                            text = donor.name,

                            fontWeight =
                                FontWeight.Bold,

                            fontSize = 20.sp
                        )

                        Spacer(
                            modifier =
                                Modifier.height(8.dp)
                        )

                        Text(

                            when (
                                selectedLanguage.value
                            ) {

                                "Kannada" ->

                                    "ರಕ್ತ ಗುಂಪು: ${
                                        donor.bloodGroup
                                    }"

                                "Hindi" ->

                                    "ब्लड ग्रुप: ${
                                        donor.bloodGroup
                                    }"

                                else ->

                                    "Blood Group: ${
                                        donor.bloodGroup
                                    }"
                            }
                        )

                        Spacer(
                            modifier =
                                Modifier.height(4.dp)
                        )

                        Text(

                            when (
                                selectedLanguage.value
                            ) {

                                "Kannada" ->

                                    "ದಾನಗಳು: ${
                                        donor.donations
                                    }"

                                "Hindi" ->

                                    "दान: ${
                                        donor.donations
                                    }"

                                else ->

                                    "Donations: ${
                                        donor.donations
                                    }"
                            }
                        )
                    }
                }
            }
        }
    }
}