package com.raktavahiniai.ui.screens.donor

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.google.firebase.firestore.FirebaseFirestore

import com.raktavahiniai.model.DonorModel
import com.raktavahiniai.utils.LanguageManager
import android.content.Intent
import android.net.Uri
import androidx.compose.ui.platform.LocalContext
import androidx.core.net.toUri

@Composable
fun DonorScreen() {

    val selectedLanguage =
        LanguageManager.selectedLanguage

    val context = LocalContext.current

    val bloodGroups = listOf(
        "All",
        "O+",
        "A+",
        "B+",
        "AB+"
    )

    var expanded by remember {
        mutableStateOf(false)
    }

    var selectedBloodGroup by remember {
        mutableStateOf("All")
    }

    var searchText by remember {
        mutableStateOf("")
    }

    var donors by remember {

        mutableStateOf(

            listOf(

                DonorModel(
                    donorName = "Rahul",
                    bloodGroup = "O+",
                    location = "Tumkur",
                    phoneNumber = "9876543210"
                ),

                DonorModel(
                    donorName = "Anjali",
                    bloodGroup = "A+",
                    location = "Bangalore",
                    phoneNumber = "9876501234"
                )
            )
        )
    }



    val filteredDonors = donors.filter { donor ->

        val matchesBloodGroup =

            selectedBloodGroup == "All" ||

                    donor.bloodGroup ==
                    selectedBloodGroup

        val matchesSearch =

            donor.donorName.contains(
                searchText,
                ignoreCase = true
            ) ||

                    donor.location.contains(
                        searchText,
                        ignoreCase = true
                    )

        matchesBloodGroup &&
                matchesSearch
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {

        Text(
            text =

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "🩸 ರಕ್ತದಾನಿಗಳು"

                    "Hindi" ->
                        "🩸 रक्तदाता"

                    else ->
                        "🩸 Blood Donors"
                },

            style =
                MaterialTheme
                    .typography
                    .headlineMedium
        )

        Spacer(modifier = Modifier.height(20.dp))

        OutlinedTextField(
            value = searchText,

            onValueChange = {
                searchText = it
            },

            modifier = Modifier.fillMaxWidth(),

            label = {

                Text(

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ದಾನಿಯನ್ನು ಹುಡುಕಿ"

                        "Hindi" ->
                            "दाता खोजें"

                        else ->
                            "Search Donor"
                    }
                )
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        Box {

            Button(
                onClick = {
                    expanded = true
                },

                modifier =
                    Modifier.fillMaxWidth()
            ) {

                Text(
                    "Blood Group: $selectedBloodGroup"
                )
            }

            DropdownMenu(
                expanded = expanded,

                onDismissRequest = {
                    expanded = false
                }
            ) {

                bloodGroups.forEach { group ->

                    DropdownMenuItem(
                        text = {
                            Text(group)
                        },

                        onClick = {

                            selectedBloodGroup =
                                group

                            expanded = false
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (
            searchText.isNotEmpty()
        ) {

            if (
                filteredDonors.isEmpty()
            ) {

                Text(

                    text =

                        when (
                            selectedLanguage.value
                        ) {

                            "Kannada" ->
                                "ಯಾವುದೇ ದಾನಿಗಳು ಕಂಡುಬಂದಿಲ್ಲ"

                            "Hindi" ->
                                "कोई दाता नहीं मिला"

                            else ->
                                "No donors found"
                        },

                    modifier =
                        Modifier.padding(
                            top = 20.dp
                        )
                )

            } else {

                LazyColumn {

                    items(filteredDonors) { donor ->

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                        ) {

                            Column(
                                modifier = Modifier
                                    .padding(20.dp)
                            ) {

                                Text(
                                    text =
                                        donor.donorName,

                                    style =
                                        MaterialTheme
                                            .typography
                                            .headlineSmall
                                )

                                Spacer(
                                    modifier =
                                        Modifier.height(8.dp)
                                )

                                Text(
                                    "Blood Group: ${
                                        donor.bloodGroup
                                    }"
                                )

                                Text(
                                    "Location: ${
                                        donor.location
                                    }"
                                )

                                Spacer(
                                    modifier =
                                        Modifier.height(12.dp)
                                )

                                Button(
                                    onClick = {

                                        val intent = Intent(
                                            Intent.ACTION_DIAL
                                        ).apply {

                                            data ="tel:${donor.phoneNumber}".toUri()
                                        }

                                        context.startActivity(intent)
                                    },

                                    modifier =
                                        Modifier.fillMaxWidth()
                                ) {

                                    Text("Contact")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}