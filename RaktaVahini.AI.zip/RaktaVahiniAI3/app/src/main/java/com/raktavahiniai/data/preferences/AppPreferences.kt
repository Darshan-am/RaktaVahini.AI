package com.raktavahiniai.data.preferences

class AppPreferences {
}