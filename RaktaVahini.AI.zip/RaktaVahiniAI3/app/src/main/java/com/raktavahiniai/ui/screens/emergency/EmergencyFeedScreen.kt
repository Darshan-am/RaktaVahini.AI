package com.raktavahiniai.ui.screens.emergencyfeed

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raktavahiniai.utils.LanguageManager

data class EmergencyPost(

    val patientName: String,

    val bloodGroup: String,

    val hospital: String
)

@Composable
fun EmergencyFeedScreen() {

    val selectedLanguage =
        LanguageManager.selectedLanguage

    val emergencyPosts = listOf(

        EmergencyPost(
            "Ramesh",
            "O+",
            "Tumkur Hospital"
        ),

        EmergencyPost(
            "Priya",
            "A-",
            "Bangalore Medical"
        ),

        EmergencyPost(
            "Karthik",
            "B+",
            "Mysore Care"
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {

        Text(
            text =

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "🚨 ತುರ್ತು ಮಾಹಿತಿ"

                    "Hindi" ->
                        "🚨 आपातकालीन फ़ीड"

                    else ->
                        "🚨 Emergency Feed"
                },

            style =
                MaterialTheme
                    .typography
                    .headlineMedium
        )

        Spacer(modifier = Modifier.height(20.dp))

        LazyColumn {

            items(emergencyPosts) { post ->

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                ) {

                    Column(
                        modifier = Modifier
                            .padding(20.dp)
                    ) {

                        Text(
                            text = post.patientName,

                            fontWeight =
                                FontWeight.Bold,

                            fontSize = 20.sp
                        )

                        Spacer(
                            modifier =
                                Modifier.height(8.dp)
                        )

                        Text(

                            when (
                                selectedLanguage.value
                            ) {

                                "Kannada" ->

                                    "ರಕ್ತ ಗುಂಪು: ${
                                        post.bloodGroup
                                    }"

                                "Hindi" ->

                                    "ब्लड ग्रुप: ${
                                        post.bloodGroup
                                    }"

                                else ->

                                    "Blood Group: ${
                                        post.bloodGroup
                                    }"
                            }
                        )

                        Spacer(
                            modifier =
                                Modifier.height(4.dp)
                        )

                        Text(

                            when (
                                selectedLanguage.value
                            ) {

                                "Kannada" ->

                                    "ಆಸ್ಪತ್ರೆ: ${
                                        post.hospital
                                    }"

                                "Hindi" ->

                                    "अस्पताल: ${
                                        post.hospital
                                    }"

                                else ->

                                    "Hospital: ${
                                        post.hospital
                                    }"
                            }
                        )

                        Spacer(
                            modifier =
                                Modifier.height(12.dp)
                        )

                        Button(
                            onClick = {

                            },

                            modifier =
                                Modifier.fillMaxWidth()
                        ) {

                            Text(

                                when (
                                    selectedLanguage.value
                                ) {

                                    "Kannada" ->
                                        "ಸಹಾಯ ಮಾಡಿ"

                                    "Hindi" ->
                                        "मदद करें"

                                    else ->
                                        "Help Now"
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}