package com.raktavahiniai.repository

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.raktavahiniai.model.Donor

object DonorRepository {

    private val database =

        FirebaseDatabase

            .getInstance()

            .reference

    fun saveDonor(

        donor: Donor

    ) {

        val donorId =

            database

                .child(
                    "donors"
                )

                .push()

                .key

                ?: return

        database

            .child(
                "donors"
            )

            .child(
                donorId
            )

            .setValue(
                donor
            )
    }

    fun getAllDonors(

        callback:

            (List<Donor>) -> Unit

    ) {

        database

            .child(
                "donors"
            )

            .addValueEventListener(

                object :

                    ValueEventListener {

                    override fun onDataChange(

                        snapshot:

                        DataSnapshot

                    ) {

                        val donorList =

                            mutableListOf<Donor>()

                        snapshot.children

                            .forEach {

                                val donor =

                                    it.getValue(

                                        Donor::class.java
                                    )

                                donor?.let {

                                    donorList.add(
                                        it
                                    )
                                }
                            }

                        callback(
                            donorList
                        )
                    }

                    override fun onCancelled(

                        error:

                        DatabaseError

                    ) {

                    }
                }
            )
    }
}