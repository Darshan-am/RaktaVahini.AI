package com.raktavahiniai.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "emergency_requests")
data class EmergencyEntity(

    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    val patientName: String,

    val hospitalName: String,

    val contactNumber: String,

    val bloodGroup: String,

    val unitsRequired: String,

    val emergencyNotes: String
)