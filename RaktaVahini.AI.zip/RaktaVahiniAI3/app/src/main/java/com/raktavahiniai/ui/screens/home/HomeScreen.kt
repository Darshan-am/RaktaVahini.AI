package com.raktavahiniai.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.raktavahiniai.navigation.NavRoutes
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HomeScreen(

    navController: NavController

) {

    val selectedLanguage =
        remember {

            mutableStateOf(
                "English"
            )
        }

    var expanded by remember {

        mutableStateOf(false)
    }

    val currentDate =

        SimpleDateFormat(

            "dd/MM/yyyy",

            Locale.getDefault()

        ).format(Date())

    val currentTime =

        SimpleDateFormat(

            "hh:mm a",

            Locale.getDefault()

        ).format(Date())

    Scaffold(

        bottomBar = {

            NavigationBar {

                NavigationBarItem(

                    selected = true,

                    onClick = { },

                    icon = {

                        Icon(
                            Icons.Default.Home,
                            null
                        )
                    },

                    label = {

                        Text(

                            when (
                                selectedLanguage.value
                            ) {

                                "Kannada" ->
                                    "ಮುಖ್ಯ"

                                "Hindi" ->
                                    "होम"

                                else ->
                                    "Home"
                            }
                        )
                    }
                )

                NavigationBarItem(

                    selected = false,

                    onClick = {

                        navController.navigate(
                            NavRoutes.PROFILE
                        )
                    },

                    icon = {

                        Icon(
                            Icons.Default.Person,
                            null
                        )
                    },

                    label = {

                        Text(

                            when (
                                selectedLanguage.value
                            ) {

                                "Kannada" ->
                                    "ಪ್ರೊಫೈಲ್"

                                "Hindi" ->
                                    "प्रोफ़ाइल"

                                else ->
                                    "Profile"
                            }
                        )
                    }
                )

                NavigationBarItem(

                    selected = false,

                    onClick = {

                        navController.navigate(
                            NavRoutes.SETTINGS
                        )
                    },

                    icon = {

                        Icon(
                            Icons.Default.Settings,
                            null
                        )
                    },

                    label = {

                        Text(

                            when (
                                selectedLanguage.value
                            ) {

                                "Kannada" ->
                                    "ಸೆಟ್ಟಿಂಗ್"

                                "Hindi" ->
                                    "सेटिंग"

                                else ->
                                    "Settings"
                            }
                        )
                    }
                )
            }
        }

    ) { padding ->

        Column(

            modifier = Modifier

                .fillMaxSize()

                .background(

                    Brush.verticalGradient(

                        listOf(

                            Color(
                                0xFF8E0E00
                            ),

                            Color(
                                0xFF1F1C18
                            )
                        )
                    )
                )

                .padding(padding)

                .padding(20.dp)

                .verticalScroll(
                    rememberScrollState()
                ),

            horizontalAlignment =
                Alignment.CenterHorizontally

        ) {

            Text(

                "🩸 Rakta-Vahini AI",

                style =
                    MaterialTheme
                        .typography
                        .headlineMedium,

                color =
                    Color.White,

                fontWeight =
                    FontWeight.Bold
            )

            Spacer(
                Modifier.height(
                    20.dp
                )
            )

            Card(

                shape =
                    RoundedCornerShape(
                        20.dp
                    )

            ) {

                Column(

                    modifier =
                        Modifier.padding(
                            16.dp
                        )
                ) {

                    Text(

                        when (
                            selectedLanguage.value
                        ) {

                            "Kannada" ->
                                "📅 ದಿನಾಂಕ : $currentDate"

                            "Hindi" ->
                                "📅 दिनांक : $currentDate"

                            else ->
                                "📅 Date : $currentDate"
                        }
                    )

                    Text(

                        when (
                            selectedLanguage.value
                        ) {

                            "Kannada" ->
                                "⏰ ಸಮಯ : $currentTime"

                            "Hindi" ->
                                "⏰ समय : $currentTime"

                            else ->
                                "⏰ Time : $currentTime"
                        }
                    )
                }
            }

            Spacer(
                Modifier.height(
                    20.dp
                )
            )

            Button(

                onClick = {

                    expanded = true
                }

            ) {

                Text(

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "🌐 ಕನ್ನಡ"

                        "Hindi" ->
                            "🌐 हिन्दी"

                        else ->
                            "🌐 English"
                    }
                )
            }

            DropdownMenu(

                expanded = expanded,

                onDismissRequest = {

                    expanded = false
                }

            ) {

                listOf(

                    "English",

                    "Kannada",

                    "Hindi"

                ).forEach {

                    DropdownMenuItem(

                        text = {

                            Text(it)
                        },

                        onClick = {

                            selectedLanguage.value =
                                it

                            expanded =
                                false
                        }
                    )
                }
            }

            Spacer(
                Modifier.height(
                    30.dp
                )
            )

            Column(

                verticalArrangement =
                    Arrangement.spacedBy(
                        16.dp
                    )

            ) {

                Row(

                    horizontalArrangement =
                        Arrangement.spacedBy(
                            16.dp
                        )
                ) {

                    GridCard(

                        Modifier.weight(
                            1f
                        ),

                        when (
                            selectedLanguage.value
                        ) {

                            "Kannada" ->
                                "ರಕ್ತ ನೋಂದಣಿ"

                            "Hindi" ->
                                "रक्त पंजीकरण"

                            else ->
                                "Blood Registration"
                        }

                    ) {

                        navController.navigate(
                            NavRoutes.ELIGIBILITY_REGISTRATION
                        )
                    }

                    GridCard(

                        Modifier.weight(
                            1f
                        ),

                        when (
                            selectedLanguage.value
                        ) {

                            "Kannada" ->
                                "ದಾನಿಗಳನ್ನು ಹುಡುಕಿ"

                            "Hindi" ->
                                "दाता खोजें"

                            else ->
                                "Search Donor"
                        }

                    ) {

                        navController.navigate(

                            NavRoutes.SEARCH_DONOR
                        )
                    }
                }

                Row(

                    horizontalArrangement =
                        Arrangement.spacedBy(
                            16.dp
                        )
                ) {

                    GridCard(

                        Modifier.weight(
                            1f
                        ),

                        when (
                            selectedLanguage.value
                        ) {

                            "Kannada" ->
                                "ತುರ್ತು ವಿನಂತಿ"

                            "Hindi" ->
                                "आपातकालीन अनुरोध"

                            else ->
                                "Emergency Request"
                        }

                    ) {

                        navController.navigate(
                            NavRoutes.BLOOD_REQUEST
                        )
                    }

                    GridCard(

                        Modifier.weight(
                            1f
                        ),

                        when (
                            selectedLanguage.value
                        ) {

                            "Kannada" ->
                                "ನೇರ ಮಾಹಿತಿ"

                            "Hindi" ->
                                "लाइव फ़ीड"

                            else ->
                                "Live Feed"
                        }

                    ) {

                        navController.navigate(
                            NavRoutes.EMERGENCY_FEED
                        )
                    }
                }

                ElevatedCard(

                    modifier =
                        Modifier.fillMaxWidth(),

                    onClick = {

                        navController.navigate(
                            NavRoutes.AI_ASSISTANT
                        )
                    },

                    colors =

                        CardDefaults
                            .elevatedCardColors(

                                containerColor =

                                    Color(
                                        0xFF4A148C
                                    )
                            ),

                    shape =

                        RoundedCornerShape(
                            24.dp
                        )

                ) {

                    Box(

                        modifier = Modifier

                            .fillMaxWidth()

                            .background(

                                Brush.verticalGradient(

                                    listOf(

                                        Color(
                                            0xFF6A1B9A
                                        ),

                                        Color(
                                            0xFF311B92
                                        )
                                    )
                                )
                            )

                            .padding(
                                28.dp
                            ),

                        contentAlignment =
                            Alignment.Center

                    ) {

                        Text(

                            text =

                                when (
                                    selectedLanguage.value
                                ) {

                                    "Kannada" ->
                                        "🤖 ಎಐ ರಕ್ತ ಸಹಾಯಕ"

                                    "Hindi" ->
                                        "🤖 एआई रक्त सहायक"

                                    else ->
                                        "🤖 AI Blood Assistant"
                                },

                            color =
                                Color.White,

                            fontWeight =
                                FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@OptIn(
    ExperimentalMaterial3Api::class
)

@Composable
fun GridCard(

    modifier: Modifier,

    title: String,

    onClick: () -> Unit

) {

    ElevatedCard(

        modifier = modifier,

        onClick = onClick,

        colors =

            CardDefaults
                .elevatedCardColors(

                    containerColor =

                        Color(
                            0xFFB71C1C
                        )
                ),

        elevation =

            CardDefaults
                .elevatedCardElevation(

                    defaultElevation =
                        12.dp
                ),

        shape =

            RoundedCornerShape(
                24.dp
            )

    ) {

        Box(

            modifier = Modifier

                .fillMaxWidth()

                .background(

                    Brush.verticalGradient(

                        listOf(

                            Color(
                                0xFFB71C1C
                            ),

                            Color(
                                0xFF7F0000
                            )
                        )
                    )
                )

                .padding(
                    26.dp
                ),

            contentAlignment =
                Alignment.Center

        ) {

            Text(

                text = title,

                color =
                    Color.White,

                fontWeight =
                    FontWeight.Bold,

                style =

                    MaterialTheme
                        .typography
                        .titleMedium
            )
        }
    }
}