package com.raktavahiniai.ui.components

class BloodGroupCard {
}