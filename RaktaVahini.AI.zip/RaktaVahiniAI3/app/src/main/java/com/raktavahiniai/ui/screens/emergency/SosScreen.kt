package com.raktavahiniai.ui.screens.sos

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.raktavahiniai.utils.LanguageManager

@Composable
fun SosScreen() {

    val selectedLanguage =
        LanguageManager.selectedLanguage

    var message by remember {
        mutableStateOf("")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
            .verticalScroll(
                rememberScrollState()
            )
    ) {

        Text(
            text =

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "🚨 ತುರ್ತು SOS"

                    "Hindi" ->
                        "🚨 आपातकालीन SOS"

                    else ->
                        "🚨 Emergency SOS"
                },

            style =
                MaterialTheme
                    .typography
                    .headlineMedium
        )

        Spacer(modifier = Modifier.height(30.dp))

        Button(
            onClick = {

                message =

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "SOS ಎಚ್ಚರಿಕೆ ಯಶಸ್ವಿಯಾಗಿ ಕಳುಹಿಸಲಾಗಿದೆ."

                        "Hindi" ->
                            "SOS अलर्ट सफलतापूर्वक भेजा गया।"

                        else ->
                            "SOS Alert Sent Successfully."
                    }
            },

            modifier =
                Modifier.fillMaxWidth()
        ) {

            Text(

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "SOS ಕಳುಹಿಸಿ"

                    "Hindi" ->
                        "SOS भेजें"

                    else ->
                        "Send SOS"
                }
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        if (message.isNotEmpty()) {

            Card(
                modifier = Modifier.fillMaxWidth()
            ) {

                Text(
                    text = message,

                    modifier =
                        Modifier.padding(20.dp)
                )
            }
        }
    }
}