package com.raktavahiniai.ui.screens.donor

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.firestore.FirebaseFirestore

data class Donor(

    val name: String = "",

    val bloodGroup: String = "",

    val phone: String = "",

    val location: String = ""
)

@Composable
fun RegisteredDonorsScreen() {

    val donorList = remember {

        mutableStateListOf<Donor>()
    }

    val selectedLanguage = remember {

        mutableStateOf("English")
    }

    val languages = listOf(

        "English",
        "Kannada",
        "Hindi"
    )

    var expanded by remember {

        mutableStateOf(false)
    }

    LaunchedEffect(Unit) {

        FirebaseFirestore

            .getInstance()

            .collection("donors")

            .get()

            .addOnSuccessListener { result ->

                donorList.clear()

                for (document in result) {

                    val donor =

                        document.toObject(
                            Donor::class.java
                        )

                    donorList.add(donor)
                }
            }
    }

    Column(

        modifier = Modifier

            .fillMaxSize()

            .padding(16.dp)

    ) {

        Text(

            text =

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "ನೋಂದಾಯಿತ ದಾನಿಗಳು"

                    "Hindi" ->
                        "पंजीकृत दाता"

                    else ->
                        "Registered Donors"
                },

            style =
                MaterialTheme
                    .typography
                    .headlineMedium
        )

        Spacer(
            modifier =
                Modifier.height(16.dp)
        )

        Box {

            Button(

                onClick = {

                    expanded = true
                }

            ) {

                Text(
                    selectedLanguage.value
                )
            }

            DropdownMenu(

                expanded = expanded,

                onDismissRequest = {

                    expanded = false
                }

            ) {

                languages.forEach { lang ->

                    DropdownMenuItem(

                        text = {

                            Text(lang)
                        },

                        onClick = {

                            selectedLanguage.value = lang

                            expanded = false
                        }
                    )
                }
            }
        }

        Spacer(
            modifier =
                Modifier.height(16.dp)
        )

        LazyColumn {

            items(donorList) { donor ->

                Card(

                    modifier = Modifier

                        .fillMaxWidth()

                        .padding(vertical = 8.dp)

                ) {

                    Column(

                        modifier =
                            Modifier.padding(16.dp)

                    ) {

                        Text(

                            when (
                                selectedLanguage.value
                            ) {

                                "Kannada" ->
                                    "ಹೆಸರು: ${donor.name}"

                                "Hindi" ->
                                    "नाम: ${donor.name}"

                                else ->
                                    "Name: ${donor.name}"
                            }
                        )

                        Text(

                            when (
                                selectedLanguage.value
                            ) {

                                "Kannada" ->
                                    "ರಕ್ತ ಗುಂಪು: ${donor.bloodGroup}"

                                "Hindi" ->
                                    "ब्लड ग्रुप: ${donor.bloodGroup}"

                                else ->
                                    "Blood Group: ${donor.bloodGroup}"
                            }
                        )

                        Text(

                            when (
                                selectedLanguage.value
                            ) {

                                "Kannada" ->
                                    "ದೂರವಾಣಿ: ${donor.phone}"

                                "Hindi" ->
                                    "फ़ोन: ${donor.phone}"

                                else ->
                                    "Phone: ${donor.phone}"
                            }
                        )

                        Text(

                            when (
                                selectedLanguage.value
                            ) {

                                "Kannada" ->
                                    "ಸ್ಥಳ: ${donor.location}"

                                "Hindi" ->
                                    "स्थान: ${donor.location}"

                                else ->
                                    "Location: ${donor.location}"
                            }
                        )
                    }
                }
            }
        }
    }
}