package com.raktavahiniai.model

data class DonorModel(

    val donorName: String = "",

    val bloodGroup: String = "",

    val location: String = "",

    val phoneNumber: String = ""
)