package com.raktavahiniai.workers

class NotificationWorker {
}