package com.raktavahiniai.ui.screens.donor

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.raktavahiniai.model.Donor
import com.raktavahiniai.repository.DonorRepository

@OptIn(
    ExperimentalMaterial3Api::class
)

@Composable
fun SearchDonorScreen() {

    val selectedLanguage =
        remember {

            mutableStateOf(
                "English"
            )
        }

    val bloodGroups = listOf(

        "A+",
        "A-",
        "B+",
        "B-",
        "AB+",
        "AB-",
        "O+",
        "O-"
    )

    var donorList by remember {

        mutableStateOf(
            listOf<Donor>()
        )
    }

    var selectedBloodGroup by remember {

        mutableStateOf("")
    }

    var expanded by remember {

        mutableStateOf(
            false
        )
    }

    LaunchedEffect(
        Unit
    ) {

        DonorRepository
            .getAllDonors {

                donorList = it
            }
    }

    val filteredDonors =

        if (

            selectedBloodGroup
                .isEmpty()

        )

            donorList

        else

            donorList.filter {

                it.bloodGroup ==

                        selectedBloodGroup
            }

    Column(

        modifier = Modifier

            .fillMaxSize()

            .padding(
                20.dp
            )

    ) {

        Text(

            "🩸 Registered Donors",

            style =

                MaterialTheme

                    .typography

                    .headlineMedium
        )

        Spacer(
            Modifier.height(
                20.dp
            )
        )

        ExposedDropdownMenuBox(

            expanded =
                expanded,

            onExpandedChange = {

                expanded =
                    !expanded
            }

        ) {

            OutlinedTextField(

                value =
                    selectedBloodGroup,

                onValueChange = { },

                readOnly = true,

                modifier =
                    Modifier.fillMaxWidth(),

                label = {

                    Text(
                        "Blood Group"
                    )
                }
            )

            ExposedDropdownMenu(

                expanded =
                    expanded,

                onDismissRequest = {

                    expanded =
                        false
                }

            ) {

                bloodGroups.forEach {

                    DropdownMenuItem(

                        text = {

                            Text(it)
                        },

                        onClick = {

                            selectedBloodGroup =
                                it

                            expanded =
                                false
                        }
                    )
                }
            }
        }

        Spacer(
            Modifier.height(
                20.dp
            )
        )

        LazyColumn {

            items(

                filteredDonors

            ) { donor ->

                Card(

                    modifier = Modifier

                        .fillMaxWidth()

                        .padding(
                            8.dp
                        )

                ) {

                    Column(

                        modifier =
                            Modifier.padding(
                                16.dp
                            )

                    ) {

                        Text(
                            "👤 ${donor.name}"
                        )

                        Text(
                            "🩸 ${donor.bloodGroup}"
                        )

                        Text(
                            "📞 ${donor.phone}"
                        )

                        Text(
                            "📍 ${donor.city}"
                        )

                        Text(
                            "📧 ${donor.email}"
                        )
                    }
                }
            }
        }
    }
}