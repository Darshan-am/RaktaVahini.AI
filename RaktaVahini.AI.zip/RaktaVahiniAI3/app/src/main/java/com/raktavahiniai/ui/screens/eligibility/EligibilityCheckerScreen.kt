// EligibilityCheckerScreen.kt

package com.raktavahiniai.ui.screens.eligibility

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun EligibilityCheckerScreen() {

    var age by remember {

        mutableStateOf("")
    }

    var weight by remember {

        mutableStateOf("")
    }

    var healthCondition by remember {

        mutableStateOf("")
    }

    var lastDonation by remember {

        mutableStateOf("")
    }

    var result by remember {

        mutableStateOf("")
    }

    Column(

        modifier = Modifier

            .fillMaxSize()

            .padding(16.dp)

            .verticalScroll(
                rememberScrollState()
            )

    ) {

        Text(

            text =
                "Blood Donation Eligibility Checker",

            style =
                MaterialTheme
                    .typography
                    .headlineMedium
        )

        Spacer(
            modifier =
                Modifier.height(20.dp)
        )

        OutlinedTextField(

            value = age,

            onValueChange = {

                age = it
            },

            label = {

                Text(
                    "Enter Age"
                )
            },

            modifier =
                Modifier.fillMaxWidth()
        )

        Spacer(
            modifier =
                Modifier.height(12.dp)
        )

        OutlinedTextField(

            value = weight,

            onValueChange = {

                weight = it
            },

            label = {

                Text(
                    "Enter Weight (kg)"
                )
            },

            modifier =
                Modifier.fillMaxWidth()
        )

        Spacer(
            modifier =
                Modifier.height(12.dp)
        )

        OutlinedTextField(

            value = healthCondition,

            onValueChange = {

                healthCondition = it
            },

            label = {

                Text(
                    "Health Condition (Good/Bad)"
                )
            },

            modifier =
                Modifier.fillMaxWidth()
        )

        Spacer(
            modifier =
                Modifier.height(12.dp)
        )

        OutlinedTextField(

            value = lastDonation,

            onValueChange = {

                lastDonation = it
            },

            label = {

                Text(
                    "Months Since Last Donation"
                )
            },

            modifier =
                Modifier.fillMaxWidth()
        )

        Spacer(
            modifier =
                Modifier.height(20.dp)
        )

        Button(

            onClick = {

                val ageInt =
                    age.toIntOrNull() ?: 0

                val weightInt =
                    weight.toIntOrNull() ?: 0

                val donationMonths =
                    lastDonation.toIntOrNull() ?: 0

                result =

                    if (

                        ageInt >= 18 &&
                        ageInt <= 60 &&

                        weightInt >= 50 &&

                        healthCondition.lowercase() == "good" &&

                        donationMonths >= 3

                    ) {

                        "✅ Eligible for Blood Donation"
                    }

                    else {

                        "❌ Not Eligible for Blood Donation"
                    }
            },

            modifier =
                Modifier.fillMaxWidth()

        ) {

            Text(
                "Check Eligibility"
            )
        }

        Spacer(
            modifier =
                Modifier.height(24.dp)
        )

        Card(

            modifier =
                Modifier.fillMaxWidth()

        ) {

            Column(

                modifier =
                    Modifier.padding(16.dp)

            ) {

                Text(

                    text = result,

                    style =
                        MaterialTheme
                            .typography
                            .titleMedium
                )
            }
        }
    }
}