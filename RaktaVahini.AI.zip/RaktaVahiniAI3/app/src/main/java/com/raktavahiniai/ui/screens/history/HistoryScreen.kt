package com.raktavahiniai.ui.screens.history

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raktavahiniai.utils.LanguageManager

data class DonationHistory(

    val hospitalName: String,

    val bloodGroup: String,

    val date: String
)

@Composable
fun HistoryScreen() {

    val selectedLanguage =
        LanguageManager.selectedLanguage

    val historyList = listOf(

        DonationHistory(
            "Tumkur Hospital",
            "O+",
            "12 May 2026"
        ),

        DonationHistory(
            "Bangalore Medical",
            "A+",
            "02 April 2026"
        ),

        DonationHistory(
            "Mysore Care",
            "B+",
            "18 March 2026"
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {

        Text(
            text =

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "🩸 ದಾನದ ಇತಿಹಾಸ"

                    "Hindi" ->
                        "🩸 दान इतिहास"

                    else ->
                        "🩸 Donation History"
                },

            style =
                MaterialTheme
                    .typography
                    .headlineMedium
        )

        Spacer(modifier = Modifier.height(20.dp))

        LazyColumn {

            items(historyList) { item ->

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                ) {

                    Column(
                        modifier = Modifier
                            .padding(20.dp)
                    ) {

                        Text(
                            text = item.hospitalName,

                            fontWeight =
                                FontWeight.Bold,

                            fontSize = 20.sp
                        )

                        Spacer(
                            modifier =
                                Modifier.height(8.dp)
                        )

                        Text(

                            when (
                                selectedLanguage.value
                            ) {

                                "Kannada" ->

                                    "ರಕ್ತ ಗುಂಪು: ${
                                        item.bloodGroup
                                    }"

                                "Hindi" ->

                                    "ब्लड ग्रुप: ${
                                        item.bloodGroup
                                    }"

                                else ->

                                    "Blood Group: ${
                                        item.bloodGroup
                                    }"
                            }
                        )

                        Spacer(
                            modifier =
                                Modifier.height(4.dp)
                        )

                        Text(

                            when (
                                selectedLanguage.value
                            ) {

                                "Kannada" ->

                                    "ದಿನಾಂಕ: ${
                                        item.date
                                    }"

                                "Hindi" ->

                                    "तारीख: ${
                                        item.date
                                    }"

                                else ->

                                    "Date: ${
                                        item.date
                                    }"
                            }
                        )
                    }
                }
            }
        }
    }
}