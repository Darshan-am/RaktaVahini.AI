package com.raktavahiniai.model

data class Donor(

    val name: String = "",

    val email: String = "",

    val phone: String = "",

    val bloodGroup: String = "",

    val city: String = ""

)