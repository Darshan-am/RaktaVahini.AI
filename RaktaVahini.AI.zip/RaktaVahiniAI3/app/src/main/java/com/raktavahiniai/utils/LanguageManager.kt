package com.raktavahiniai.utils

import androidx.compose.runtime.mutableStateOf

object LanguageManager {

    val selectedLanguage =
        mutableStateOf("English")
}