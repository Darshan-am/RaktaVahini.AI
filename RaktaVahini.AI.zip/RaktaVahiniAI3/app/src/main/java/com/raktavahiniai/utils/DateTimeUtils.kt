package com.raktavahiniai.utils

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DateTimeUtils {

    fun getCurrentDate(): String {

        val formatter =
            SimpleDateFormat(
                "dd MMM yyyy",
                Locale.getDefault()
            )

        return formatter.format(
            Date()
        )
    }

    fun getCurrentTime(): String {

        val formatter =
            SimpleDateFormat(
                "hh:mm a",
                Locale.getDefault()
            )

        return formatter.format(
            Date()
        )
    }
}