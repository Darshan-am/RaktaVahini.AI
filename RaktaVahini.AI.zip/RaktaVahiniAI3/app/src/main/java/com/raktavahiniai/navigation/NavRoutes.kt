package com.raktavahiniai.navigation

object NavRoutes {

    const val SPLASH = "splash"

    const val LOGIN = "login"

    const val REGISTER = "register"

    const val HOME = "home"

    const val HISTORY = "history"

    const val PROFILE = "profile"

    const val SETTINGS = "settings"

    const val DONOR = "donor"

    const val EMERGENCY = "emergency"

    const val EMERGENCY_HISTORY =
        "emergency_history"

    const val SOS = "sos"

    const val EMERGENCY_FEED =
        "emergency_feed"

    const val DONOR_MAP =
        "donor_map"

    const val AI_ASSISTANT =
        "ai_assistant"

    const val RANKING =
        "ranking"

    const val BLOOD_REQUEST =
        "blood_request"

    const val ELIGIBILITY_CHECKER =
        "eligibility_checker"

    const val REGISTERED_DONORS =
        "registered_donors"

    const val ELIGIBILITY_REGISTRATION =
        "eligibility_registration"

    const val SEARCH_DONOR =
        "search_donor"
}