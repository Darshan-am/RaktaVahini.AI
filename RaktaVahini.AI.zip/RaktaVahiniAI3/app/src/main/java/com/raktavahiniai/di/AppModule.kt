package com.raktavahiniai.di

class AppModule {
}