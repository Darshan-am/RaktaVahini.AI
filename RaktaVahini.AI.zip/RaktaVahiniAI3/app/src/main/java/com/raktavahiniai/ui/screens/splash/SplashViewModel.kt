package com.raktavahiniai.ui.screens.splash

class SplashViewModel {
}