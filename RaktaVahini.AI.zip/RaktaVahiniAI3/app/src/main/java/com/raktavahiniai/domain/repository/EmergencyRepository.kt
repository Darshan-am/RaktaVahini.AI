package com.raktavahiniai.domain.repository

class EmergencyRepository {
}