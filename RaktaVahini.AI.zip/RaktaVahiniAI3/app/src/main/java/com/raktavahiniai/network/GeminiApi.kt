package com.raktavahiniai.network

import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

object GeminiApi {

    private const val API_KEY =
        "AIzaSyAU4sznCpx-MI6IA-HWyFSPimTQcGhvUJI"

    private val client =
        OkHttpClient()

    fun askGemini(

        question: String,

        callback: (String) -> Unit

    ) {

        val url =
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$API_KEY"
        val json = """

        {
          "contents": [
            {
              "parts": [
                {
                  "text": "$question"
                }
              ]
            }
          ]
        }

        """.trimIndent()

        val body =

            json.toRequestBody(
                "application/json"
                    .toMediaType()
            )

        val request =

            Request.Builder()

                .url(url)

                .post(body)

                .build()

        client.newCall(request)

            .enqueue(

                object : Callback {

                    override fun onFailure(

                        call: Call,

                        e: IOException

                    ) {

                        callback(
                            "Connection Error"
                        )
                    }

                    override fun onResponse(

                        call: Call,

                        response: Response

                    ) {

                        try {

                            val responseBody =
                                response.body?.string()

                            if (
                                responseBody.isNullOrEmpty()
                            ) {

                                callback(
                                    "Empty Response"
                                )

                                return
                            }

                            val jsonObject =
                                JSONObject(responseBody)

                            if (
                                jsonObject.has("error")
                            ) {

                                val error =

                                    jsonObject

                                        .getJSONObject(
                                            "error"
                                        )

                                        .getString(
                                            "message"
                                        )

                                callback(
                                    error
                                )

                                return
                            }

                            val candidates =

                                jsonObject

                                    .getJSONArray(
                                        "candidates"
                                    )

                            val text =

                                candidates

                                    .getJSONObject(0)

                                    .getJSONObject(
                                        "content"
                                    )

                                    .getJSONArray(
                                        "parts"
                                    )

                                    .getJSONObject(0)

                                    .getString(
                                        "text"
                                    )

                            callback(text)

                        }

                        catch (e: Exception) {

                            callback(
                                "Parsing Error"
                            )
                        }
                    }
                }
            )
    }
}