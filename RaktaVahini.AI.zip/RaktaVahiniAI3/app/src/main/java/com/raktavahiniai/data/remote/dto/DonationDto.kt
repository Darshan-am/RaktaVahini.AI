package com.raktavahiniai.data.remote.dto

class DonationDto {
}